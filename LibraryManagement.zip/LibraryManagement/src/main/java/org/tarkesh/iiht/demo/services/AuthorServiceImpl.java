package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.tarkesh.iiht.demo.model.Author;

public class AuthorServiceImpl implements AuthorService{

	@Override
	public Author findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Author> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author save(Author author) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Author author) {
		// TODO Auto-generated method stub
		
	}

}
