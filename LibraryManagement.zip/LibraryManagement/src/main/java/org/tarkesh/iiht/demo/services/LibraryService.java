package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.tarkesh.iiht.demo.model.Book;
import org.tarkesh.iiht.demo.model.Library;
import org.tarkesh.iiht.demo.repositories.LibraryRepository;

import lombok.extern.log4j.Log4j;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

@Service
@Log4j
public interface LibraryService {
	public Library findByName(String name);

	public List<Library> findAll();

	public Library save(Library library);

	public void delete(Library library);
}
