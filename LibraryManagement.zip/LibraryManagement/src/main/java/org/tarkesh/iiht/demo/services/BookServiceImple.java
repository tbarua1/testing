package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.tarkesh.iiht.demo.model.Book;

public class BookServiceImple implements BookService{

	@Override
	public Book findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Book book) {
		// TODO Auto-generated method stub
		
	}

}
