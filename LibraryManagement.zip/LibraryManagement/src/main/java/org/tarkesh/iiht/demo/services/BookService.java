package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.tarkesh.iiht.demo.model.Book;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public interface BookService {
	public Book findByName(String name);
	 public List<Book> findAll();
	 public Book save(Book book);
	 public void delete(Book book);
}
