package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.tarkesh.iiht.demo.model.Author;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public interface AuthorService {
	public Author findByName(String name);
	 public List<Author> findAll();
	 public Author save(Author author);
	 public void delete(Author author);
}
