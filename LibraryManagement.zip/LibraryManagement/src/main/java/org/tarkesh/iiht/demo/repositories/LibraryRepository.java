package org.tarkesh.iiht.demo.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.tarkesh.iiht.demo.model.Book;
import org.tarkesh.iiht.demo.model.Library;
@Repository
public interface LibraryRepository extends JpaRepository<Library, Long> {

	Page<Book> findById(Long id, Pageable pageable);

}
