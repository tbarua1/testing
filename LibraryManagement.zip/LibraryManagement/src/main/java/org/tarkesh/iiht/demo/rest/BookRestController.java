package org.tarkesh.iiht.demo.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.tarkesh.iiht.demo.model.Book;
import org.tarkesh.iiht.demo.repositories.BookRepository;

@RestController
public class BookRestController {
	@Autowired
	private BookRepository BookRepository;
	
	@GetMapping("/book")
	public List<Book> getAllBooks() {
		List<Book> Book = BookRepository.findAll();
		return Book;
	}
	@PostMapping("/book")
	public Book createBook(@RequestBody Book book) {
		Book bookSaved=BookRepository.save(book);
		return bookSaved;
	}
	@PutMapping("/book")
	public Book updateBook(@RequestBody Book book) {
		Optional<Book> b=BookRepository.findById(book.getId());
		b.get().getAuthors().addAll(book.getAuthors());
		return book;
	}
}
