package org.tarkesh.iiht.demo.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.tarkesh.iiht.demo.model.Book;
import org.tarkesh.iiht.demo.model.Library;
import org.tarkesh.iiht.demo.repositories.LibraryRepository;

@RestController
public class LibraryRestController {
	@Autowired
	private LibraryRepository libraryRepository;

	@GetMapping("/libraries")
	public List<Library> getAllCommentsByPostId(Pageable pageable) {
		List<Library> b = libraryRepository.findAll();
		return b;
	}
	@PostMapping("/libraries")
	public Library createLibrary(@RequestBody Library library) {
		Library librarySaved=libraryRepository.save(library);
		return librarySaved;
	}
	@PutMapping("/libraries")
	public Boolean updateLibrary(@RequestBody Library library) {
		
		Optional<Library> librarySaved=libraryRepository.findById(library.getId());
		List<Book> books = librarySaved.get().getBooks();
		return books.addAll(library.getBooks());
		
	}
//
//    @PostMapping("/posts/{postId}/comments")
//    public Comment createComment(@PathVariable (value = "postId") Long postId,
//                                 @Valid @RequestBody Comment comment) {
//        return postRepository.findById(postId).map(post -> {
//            comment.setPost(post);
//            return commentRepository.save(comment);
//        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
//    }
//
//    @PutMapping("/posts/{postId}/comments/{commentId}")
//    public Comment updateComment(@PathVariable (value = "postId") Long postId,
//                                 @PathVariable (value = "commentId") Long commentId,
//                                 @Valid @RequestBody Comment commentRequest) {
//        if(!postRepository.existsById(postId)) {
//            throw new ResourceNotFoundException("PostId " + postId + " not found");
//        }
//
//        return commentRepository.findById(commentId).map(comment -> {
//            comment.setText(commentRequest.getText());
//            return commentRepository.save(comment);
//        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
//    }
//
//    @DeleteMapping("/posts/{postId}/comments/{commentId}")
//    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
//                              @PathVariable (value = "commentId") Long commentId) {
//        return commentRepository.findByIdAndPostId(commentId, postId).map(comment -> {
//            commentRepository.delete(comment);
//            return ResponseEntity.ok().build();
//        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
//    }
}
