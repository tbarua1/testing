package org.tarkesh.iiht.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.tarkesh.iiht.demo.model.Address;
@Repository
public interface AddressRepository extends JpaRepository<Address, Long>{

}
