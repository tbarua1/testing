package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.tarkesh.iiht.demo.model.Library;

public class LibraryServviceImpl implements LibraryService{

	@Override
	public Library findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Library> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Library save(Library library) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Library library) {
		// TODO Auto-generated method stub
		
	}

}
