package org.tarkesh.iiht.demo.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.tarkesh.iiht.demo.model.Address;
import org.tarkesh.iiht.demo.model.Author;
import org.tarkesh.iiht.demo.repositories.AddressRepository;

@RestController
public class AddressRestController {
	
	@Autowired
	private AddressRepository addressRepository;
	
	@GetMapping("/address")
	public List<Address> getAllAddress() {
		List<Address> address = addressRepository.findAll();
		return address;
	}
	@PostMapping("/address")
	public Address createAddress(@RequestBody Address address) {
		Address add=addressRepository.save(address);
		return add;
	}
}
