package org.tarkesh.iiht.demo.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class BookController {

}
