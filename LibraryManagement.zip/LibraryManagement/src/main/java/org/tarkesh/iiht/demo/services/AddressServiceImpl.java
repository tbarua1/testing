package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.tarkesh.iiht.demo.model.Address;

public class AddressServiceImpl implements AddressService{

	@Override
	public Address findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Address> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Address save(Address address) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Address address) {
		// TODO Auto-generated method stub
		
	}

}
