package org.tarkesh.iiht.demo.repositories;

import java.util.Optional;

//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.tarkesh.iiht.demo.model.Book;
@Repository
public interface BookRepository extends JpaRepository<Book, Long>{
	Page<Book> findById(Long id, Pageable pageable);
//	Page<PSubject> findByType(String type, Pageable pageable);
//	List<PSubject> findByType(String type);
//	Page<PSubject> findByMacaddress(String macaddress, Pageable pageable);
//	List<PSubject> findByMacaddress(String macaddress);
//	List<PSubject> findByUri(String uri);
//    
}
