package org.tarkesh.iiht.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.tarkesh.iiht.demo.model.Address;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public interface AddressService {
	public Address findByName(String name);

	public List<Address> findAll();

	public Address save(Address address);

	public void delete(Address address);
}
