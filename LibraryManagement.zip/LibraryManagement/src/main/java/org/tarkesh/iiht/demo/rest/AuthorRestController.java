package org.tarkesh.iiht.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.tarkesh.iiht.demo.repositories.AddressRepository;
import org.tarkesh.iiht.demo.repositories.AuthorRepository;
import org.tarkesh.iiht.demo.repositories.BookRepository;
import org.tarkesh.iiht.demo.model.Address;
import org.tarkesh.iiht.demo.model.Author;

@RestController
public class AuthorRestController {
	@Autowired
	private AuthorRepository authorRepository;
	
	@GetMapping("/author/name/{name}")
	public ResponseEntity<Author> getEmployeeByName(@PathVariable String name) {
		Author author = authorRepository.findByName(name);
		return new ResponseEntity<Author>(author, HttpStatus.OK);
	}
	@GetMapping("/author/email/{email}")
	public ResponseEntity<Author> getEmployeeByEmail(@PathVariable String email) {
		Author author = authorRepository.findByEmail(email);
		return new ResponseEntity<Author>(author, HttpStatus.OK);
	}
	
	@GetMapping("/author")
	public List<Author> getAllAuthors() {
		List<Author> author = authorRepository.findAll();
		return author;
	}
	@PostMapping("/author")
	public Author createAuthor(@RequestBody Author author) {
		Author authr=authorRepository.save(author);
		return authr;
	}

//	@Autowired
//    private AuthorRepository authorRepository;
//
//    @Autowired
//    private BookRepository bookRepository;

//    @GetMapping("/posts/{postId}/comments")
//    public Page<Comment> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
//                                                Pageable pageable) {
//        return authorRepository.findByPostId(postId, pageable);
//    }
//
//    @PostMapping("/posts/{postId}/comments")
//    public Comment createComment(@PathVariable (value = "postId") Long postId,
//                                 @Valid @RequestBody Comment comment) {
//        return bookRepository.findById(postId).map(post -> {
//            comment.setPost(post);
//            return authorRepository.save(comment);
//        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
//    }
//
//    @PutMapping("/posts/{postId}/comments/{commentId}")
//    public Comment updateComment(@PathVariable (value = "postId") Long postId,
//                                 @PathVariable (value = "commentId") Long commentId,
//                                 @Valid @RequestBody Comment commentRequest) {
//        if(!bookRepository.existsById(postId)) {
//            throw new ResourceNotFoundException("PostId " + postId + " not found");
//        }
//
//        return authorRepository.findById(commentId).map(comment -> {
//            comment.setText(commentRequest.getText());
//            return authorRepository.save(comment);
//        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
//    }
//
//    @DeleteMapping("/posts/{postId}/comments/{commentId}")
//    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
//                              @PathVariable (value = "commentId") Long commentId) {
//        return authorRepository.findByIdAndPostId(commentId, postId).map(comment -> {
//            authorRepository.delete(comment);
//            return ResponseEntity.ok().build();
//        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
//    }
}
